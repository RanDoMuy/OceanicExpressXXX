function open_signup() {
    document.getElementById("signup").style.width = "100%";
}

function close_signup() {
    document.getElementById("signup").style.width = "0%";
}

function open_login() {
    document.getElementById("login").style.width = "100%";
}

function close_login() {
    document.getElementById("login").style.width = "0%";
}